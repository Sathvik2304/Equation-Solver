# Equation-Solver
Solving Handwritten Mathematical Equations using Computer Vision

```
uvicorn app:app --port:8000 --reload
```
