import './App.css';
import Canvas from './Canvas';

function App() {
  return (
    <div className="App">
      <Canvas />
    </div>
  );
}

export default App;